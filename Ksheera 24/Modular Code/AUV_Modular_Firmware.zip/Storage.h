#ifndef STORAGE_H
#define STORAGE_H
#include <Arduino.h>

void initStorage();
void logToSD(const String& data);

#endif
