#include <Arduino.h>
#include "Sensors.h"
#include "Storage.h"
#include "Telemetry.h"
#include "Control.h"

void setup() {
  Serial.begin(9600);
  GPS_SERIAL.begin(9600);

  initSensors();
  initStorage();
  initTelemetry();
  initControl();
}

void loop() {
  readAllSensors();
  handleDepthControl();
  String logLine = buildDataString();
  logToSD(logLine);
  sendTelemetry(logLine);
  delay(1000);
}
