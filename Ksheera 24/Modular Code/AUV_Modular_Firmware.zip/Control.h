#ifndef CONTROL_H
#define CONTROL_H
#include <Arduino.h>

void initControl();
void handleDepthControl();

#endif
